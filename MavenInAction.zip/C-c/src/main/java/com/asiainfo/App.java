package com.asiainfo;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
    	Dd d = new Dd();
        System.out.println( "Hello World!" );
    }
}
