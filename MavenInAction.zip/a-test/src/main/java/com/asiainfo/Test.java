package com.asiainfo;

import java.lang.reflect.InvocationTargetException;
import java.util.HashMap;
import java.util.Map;

/**
 * 测试
 * 
 * @author zhangzhiwang
 * @date 2017年2月14日 下午4:10:07
 */
public class Test {
	public static void main(String[] args) {
//		System.out.println(test(3));
		System.out.println(test2(3));
	}

	public static String test(int i) {
		String s = "";
		if (i == 1) {
			s = "a";
		} else if (i == 2) {
			s = "b";
		} else {
			s = "c";
		}
		return s;
	}
	
	public static String test2(int i) {
		String s = "";
		Map<Integer, String> map = new HashMap<Integer, String>();
		map.put(1, "a");
		map.put(2, "b");
		s = map.get(i) == null ? "c" : map.get(i);
		return s;
	}
}
