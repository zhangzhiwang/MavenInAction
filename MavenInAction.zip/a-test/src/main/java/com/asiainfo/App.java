package com.asiainfo;

/**
 * Hello world!
 *
 */
public class App {
	public static void main(String[] args) {
//		AccountCaptchaServiceImpl a = new AccountCaptchaServiceImpl();
//		AccountCaptchaServiceTest a1 = new AccountCaptchaServiceTest();
		System.out.println("Hello World!");
	}
}
