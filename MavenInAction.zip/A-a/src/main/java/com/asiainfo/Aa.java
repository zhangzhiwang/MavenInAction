package com.asiainfo;

public class Aa {
	public static void main(String[] args) {

	}
}
