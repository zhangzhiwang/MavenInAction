package com.asiainfo;

public class AaTestBase {

}
