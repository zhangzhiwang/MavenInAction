package com.asiainfo;

import org.junit.Assert;

/**
 * Hello world!
 *
 */
public class App {
	public static void main(String[] args) {
		TestATest a = new TestATest();
	}

}
