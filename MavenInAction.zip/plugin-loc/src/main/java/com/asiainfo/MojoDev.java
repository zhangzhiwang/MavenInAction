package com.asiainfo;

import org.apache.maven.plugin.AbstractMojo;
import org.apache.maven.plugin.MojoExecutionException;
import org.apache.maven.plugin.MojoFailureException;
import org.apache.maven.plugins.annotations.Mojo;
import org.apache.maven.plugins.annotations.Parameter;

/**
 * maven插件开发
 * 
 * @author zhangzhiwang
 * @date 2017年3月2日 上午10:11:53
 */
@Mojo(name = "dev")
public class MojoDev extends AbstractMojo {
	@Parameter(defaultValue="zzw")
	private String abcdefg;

	public void execute() throws MojoExecutionException, MojoFailureException {
		System.out.println("Hello maven plugin.I'm " + abcdefg);
	}
}
