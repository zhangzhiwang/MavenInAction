package ${package}.service.impl;

public class ServiceImpl implements IService {}