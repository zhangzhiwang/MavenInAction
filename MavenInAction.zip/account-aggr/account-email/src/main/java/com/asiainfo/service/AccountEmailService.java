package com.asiainfo.service;

/**
 * 邮件服务
 * 
 * @author zhangzhiwang
 * @date 2017年2月7日 下午3:44:25
 */
public interface AccountEmailService {
	void sendMail(String to, String subject, String htmlText);
}
