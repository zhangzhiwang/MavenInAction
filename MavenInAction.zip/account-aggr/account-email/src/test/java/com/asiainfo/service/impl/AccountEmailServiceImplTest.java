package com.asiainfo.service.impl;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.mail.javamail.JavaMailSender;

import com.asiainfo.service.AccountEmailService;
import com.icegreen.greenmail.util.GreenMail;
import com.icegreen.greenmail.util.ServerSetup;


/**
 * 邮件发送单元测试
 * 
 * @author zhangzhiwang
 * @date 2017年2月7日 下午4:53:41
 */
public class AccountEmailServiceImplTest {
	private GreenMail greenMail;
	
	@Before
	public void startMailServer() {
//		greenMail = new GreenMail(ServerSetup.SMTP);
		greenMail = new GreenMail(new ServerSetup(2500, null, "smtp"));
		greenMail.setUser("zhangzw8@asiainfo.com", "Baidu.com3");
		greenMail.start();
	}
	
	@Test
	public void testSendMail() {
		ApplicationContext ctx = new ClassPathXmlApplicationContext("account-email.xml");
		AccountEmailService accountEmailService = (AccountEmailService) ctx.getBean("accountEmailService");
		accountEmailService.sendMail("934109401@qq.com", "test subject", "<h3>Test content...</h3>");
		assertTrue(true);
	}

	@After
	public void stopMailServer() {
		greenMail.stop();
	}
	
//	public static void main(String[] args) {
//		GreenMail greenMail = new GreenMail(new ServerSetup(2500, null, "smtp"));
//		greenMail.setUser("zhangzw8@asiainfo.com", "Baidu.com3");
//		greenMail.start();
//	}
}
