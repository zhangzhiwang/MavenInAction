package com.asiainfo.service;

import com.asiainfo.entity.Account;

/**
 * 账户持久化服务
 * 
 * @author zhangzhiwang
 * @date 2017年2月12日 下午8:17:48
 */
public interface AccountPersistService {
	/**
	 * 增
	 * 
	 * @author zhangzhiwang
	 * @date 2017年2月12日 下午8:18:25
	 * @param account
	 * @return
	 */
	Account insert(Account account);

	/**
	 * 删
	 * 
	 * @author zhangzhiwang
	 * @date 2017年2月12日 下午8:18:48
	 * @param id
	 */
	void delete(String id);

	/**
	 * 改
	 * 
	 * @author zhangzhiwang
	 * @date 2017年2月12日 下午8:19:17
	 * @param account
	 * @return
	 */
	Account update(Account account);

	/**
	 * 查
	 * 
	 * @author zhangzhiwang
	 * @date 2017年2月12日 下午8:19:49
	 * @param id
	 * @return
	 */
	Account query(String id);
}
