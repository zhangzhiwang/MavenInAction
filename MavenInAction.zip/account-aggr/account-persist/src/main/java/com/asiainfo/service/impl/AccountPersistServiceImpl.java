package com.asiainfo.service.impl;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.io.Writer;
import java.util.List;

import org.dom4j.Document;
import org.dom4j.DocumentException;
import org.dom4j.DocumentFactory;
import org.dom4j.Element;
import org.dom4j.io.OutputFormat;
import org.dom4j.io.SAXReader;
import org.dom4j.io.XMLWriter;

import com.asiainfo.entity.Account;
import com.asiainfo.service.AccountPersistService;

public class AccountPersistServiceImpl implements AccountPersistService {
	private String file;
	private SAXReader reader = new SAXReader();
	private static final String ELEMENT_ROOT = "account-persist";
	private static final String ELEMENT_ACCOUNTS = "accounts";

	public Account insert(Account account) {
		Document doc = readDocument();

		Element accountsEle = doc.getRootElement().element(ELEMENT_ACCOUNTS);

		accountsEle.add(buildAccountElement(account));

		writeDocument(doc);

		return account;
	}

	public void delete(String id) {
	}

	public Account update(Account account) {
		return null;
	}

	public Account query(String id) {
		Document doc = readDocument();
		Element accountsEle = doc.getRootElement().element(ELEMENT_ACCOUNTS);
		List<Element> el = accountsEle.elements();
		for (Element accountEle : el) {
			return buildAccount(accountEle);
		}
		return null;
	}

	private Account buildAccount(Element element) {
		Account account = new Account();
		account.setId(element.elementText("id"));
		account.setName(element.elementText("name"));
		account.setEmail(element.elementText("email"));
		account.setPassword(element.elementText("password"));
		account.setActivated("true".equals(element.elementText("activated")) ? true : false);
		return account;
	}

	private Document readDocument() {
		File dataFile = new File(file);
		if (!dataFile.exists()) {
			dataFile.getParentFile().mkdirs();
			Document doc = DocumentFactory.getInstance().createDocument();
			Element rootEle = doc.addElement(ELEMENT_ROOT);
			rootEle.addElement(ELEMENT_ACCOUNTS);
			writeDocument(doc);
		}
		try {
			return reader.read(new File(file));
		} catch (DocumentException e) {
			e.printStackTrace();
		}
		return null;
	}

	private void writeDocument(Document doc) {
		Writer out = null;
		try {
			out = new OutputStreamWriter(new FileOutputStream(file), "utf-8");
			XMLWriter writer = new XMLWriter(out, OutputFormat.createPrettyPrint());
			writer.write(doc);
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			if (out != null) {
				try {
					out.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}
	}

	private Element buildAccountElement(Account account) {
		Element element = DocumentFactory.getInstance().createElement("account");

		element.addElement("id").setText(account.getId());
		element.addElement("name").setText(account.getName());
		element.addElement("email").setText(account.getEmail());
		element.addElement("password").setText(account.getPassword());
		element.addElement("activated").setText(account.isActivated() ? "true" : "false");

		return element;
	}

	public String getFile() {
		return file;
	}

	public void setFile(String file) {
		this.file = file;
	}
	
	
}
