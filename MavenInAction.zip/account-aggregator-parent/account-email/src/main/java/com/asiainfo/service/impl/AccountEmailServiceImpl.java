package com.asiainfo.service.impl;

import javax.mail.MessagingException;
import javax.mail.internet.MimeMessage;

import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;

import com.asiainfo.service.AccountEmailService;

/**
 * 邮件服务实现类
 * 
 * @author zhangzhiwang
 * @date 2017年2月7日 下午3:47:02
 */
public class AccountEmailServiceImpl implements AccountEmailService {
	private JavaMailSender javaMailSender;
	private String systemEmail;

	public JavaMailSender getJavaMailSender() {
		return javaMailSender;
	}

	public void setJavaMailSender(JavaMailSender javaMailSender) {
		this.javaMailSender = javaMailSender;
	}

	public String getSystemEmail() {
		return systemEmail;
	}

	public void setSystemEmail(String systemEmail) {
		this.systemEmail = systemEmail;
	}

	@Override
	public void sendMail(String to, String subject, String htmlText) {
		try {
			MimeMessage mimeMessage = javaMailSender.createMimeMessage();
			MimeMessageHelper messageHelper = new MimeMessageHelper(mimeMessage);
			messageHelper.setFrom(systemEmail);
			messageHelper.setTo(to);
			messageHelper.setSubject(subject);
			messageHelper.setText(htmlText, true);

			javaMailSender.send(mimeMessage);
			System.out.println("发送完成！");
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
