package com.asiainfo.service.impl;

import javax.mail.internet.MimeMessage;

import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;



public class ServiceImplTest  {
	private JavaMailSender javaMailSender;
	private String systemEmail;

	public JavaMailSender getJavaMailSender() {
		return javaMailSender;
	}

	public void setJavaMailSender(JavaMailSender javaMailSender) {
		this.javaMailSender = javaMailSender;
	}

	public String getSystemEmail() {
		return systemEmail;
	}

	public void setSystemEmail(String systemEmail) {
		this.systemEmail = systemEmail;
	}

	public void sendMail(String to, String subject, String htmlText) {
		try {
			MimeMessage mimeMessage = javaMailSender.createMimeMessage();
			MimeMessageHelper messageHelper = new MimeMessageHelper(mimeMessage);
			messageHelper.setFrom(systemEmail);
			messageHelper.setTo(to);
			messageHelper.setSubject(subject);
			messageHelper.setText(htmlText, true);

			javaMailSender.send(mimeMessage);
			System.out.println("发送完成！");
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

//	private void test() {
//		AccountPersistServiceImpl a = new AccountPersistServiceImpl();
//	}
}
