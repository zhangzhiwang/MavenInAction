package com.asiainfo;

import org.junit.Assert;
import org.junit.Test;

/**
 * 测试maven-surefire-plugin的默认测试类命名模式，以及自定义测试类名
 * 
 * @author zhangzhiwang
 * @date 2017年2月20日 上午10:07:18
 */
public class ThisIsTestZZW {
	@Test
	public void test() {
		Assert.assertTrue(true);
	}
}
