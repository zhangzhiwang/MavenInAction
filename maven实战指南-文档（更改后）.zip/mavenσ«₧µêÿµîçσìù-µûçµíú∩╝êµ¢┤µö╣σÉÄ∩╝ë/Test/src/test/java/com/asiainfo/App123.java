package com.asiainfo;

import org.junit.Assert;
import org.junit.Test;

/**
 * Unit test for simple App.
 */
public class App123 {
	@Test
	public void testSay() {
		App.say("zzw");
		System.out.println("App123");
		Assert.assertTrue(true);
	}
}
