package com.asiainfo;

import org.junit.Assert;
import org.junit.Test;

/**
 * Unit test for simple App.
 */
public class App124 {
	@Test
	public void testSay() {
//		App.say("zzw");
		System.out.println("App124");
		Assert.assertTrue(true);
	}
}
