package com.asiainfo;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
        System.out.println( "Hello World!" );
    }
    
    public static void say(String name) {
    	System.out.println("I'm " + name + ".");
    }
}
