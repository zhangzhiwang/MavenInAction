package cn.com.mvnbook.ssm.demo.dao.mybatis.impl;
import cn.com.mvnbook.ssh.demo.dao.IMvnUserDAO;

public interface IMvnUserDAO4MyBatis extends IMvnUserDAO {

}

